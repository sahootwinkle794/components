<?php
require_once 'config.php';

// Check if data already exists in the database
$checkExistingDataQuery = "SELECT COUNT(*) FROM user";
$result = $conn->query($checkExistingDataQuery);
if ($result) {
    $count = $result->fetch_assoc()['COUNT(*)'];
    if ($count > 0) {
        die("Data already exists in the database. Cannot upload file.");
    }
} else {
    die("Error checking existing data: " . $conn->error);
}

// Proceed with file upload
if(isset($_FILES["fileToUpload"])) {
    $file_tmp = $_FILES["fileToUpload"]["tmp_name"];

    // Load the Excel file
    require 'PHPExcel/Classes/PHPExcel.php';
    $objPHPExcel = PHPExcel_IOFactory::load($file_tmp);

    // Prepare SQL statement for insertion
    $sql = "INSERT INTO user (name, email) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Error preparing statement: " . $conn->error);
    }

    // Iterate over the rows and insert into database
    $successCount = 0;
    foreach ($objPHPExcel->getWorksheetIterator() as $worksheet) {
        foreach ($worksheet->getRowIterator() as $row) {
            // Initialize variables
            $name = '';
            $email = '';

            $cellIterator = $row->getCellIterator();
            $cellIterator->setIterateOnlyExistingCells(false); // Loop through all cells, even if empty
            $cellData = [];
            foreach ($cellIterator as $cell) {
                $cellData[] = $cell->getValue();
            }

            // Extracting data from cells
            $name = isset($cellData[0]) ? $cellData[0] : '';
            $email = isset($cellData[1]) ? $cellData[1] : '';

            // Bind parameters for insert statement
            $stmt->bind_param("ss", $name, $email);

            // Execute the insert statement
            if ($stmt->execute()) {
                $successCount++;
            } else {
                echo "Error executing statement: " . $stmt->error;
            }
        }
    }

    $stmt->close(); // Close the statement
    $conn->close(); // Close connection
    echo "Data imported successfully. $successCount new records added.";
} else {
    echo "No file uploaded.";
}
?>
