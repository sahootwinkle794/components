<?php
require_once 'config.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Excel File</title>
    <style>
        #progress-container {
            width: 100%;
            background-color: #f0f0f0;
            border: 1px solid #ccc;
            height: 20px;
            position: relative;
            margin-top: 20px;
            display: none; /* Hide progress bar initially */
        }

        #progress-bar {
            width: 0%;
            height: 100%;
            background-color: green;
            position: absolute;
            top: 0;
            left: 0;
        }
    </style>
</head>
<body>
    <form id="uploadForm" enctype="multipart/form-data">
        Select Excel File to Upload:
        <input type="file" name="fileToUpload" id="fileToUpload">
        <input type="submit" value="Upload File" name="submit">
    </form>
    <div id="progress-container">
        <div id="progress-bar"></div>
    </div>

    <script>
        document.getElementById("uploadForm").addEventListener("submit", function(event) {
            event.preventDefault(); // Prevent default form submission

            var formData = new FormData(this);
            var xhr = new XMLHttpRequest();

            xhr.open("POST", "upload.php");

            // Update progress bar as upload progresses
            xhr.upload.addEventListener("progress", function(event) {
                if (event.lengthComputable) {
                    var progress = (event.loaded / event.total) * 100;
                    document.getElementById("progress-bar").style.width = progress + "%";
                }
            });

            // Show progress bar when upload starts
            xhr.addEventListener("loadstart", function() {
                document.getElementById("progress-container").style.display = "block";
            });

            // Hide progress bar and reset form when upload completes
            xhr.addEventListener("load", function() {
                document.getElementById("progress-container").style.display = "none";
                document.getElementById("uploadForm").reset();
                alert(xhr.responseText);
            });

            // Handle errors
            xhr.addEventListener("error", function() {
                alert("An error occurred while uploading the file.");
            });

            // Send form data
            xhr.send(formData);
        });
    </script>
</body>
</html>
