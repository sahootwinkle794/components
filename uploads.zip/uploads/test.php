<?php
require_once 'config.php';

if(isset($_POST["submit"])) {
    // Check if a file was uploaded
    if ($_FILES["fileToUpload"]["error"] == UPLOAD_ERR_OK) {
        // Get file details
        $file_name = $_FILES["fileToUpload"]["name"];
        $file_tmp = $_FILES["fileToUpload"]["tmp_name"];
        $file_type = $_FILES["fileToUpload"]["type"];
        $file_size = $_FILES["fileToUpload"]["size"];

        // Check if the file is an Excel file
        $allowed_types = array("application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        if (in_array($file_type, $allowed_types)) {
            // Load the Excel file
            require 'PHPExcel/Classes/PHPExcel.php';
            $objPHPExcel = PHPExcel_IOFactory::load($file_tmp);

            // Prepare and bind SQL statement for existence check
            $checkQuery = "SELECT COUNT(*) FROM user WHERE name = ? AND email = ?";
            $checkStmt = $conn->prepare($checkQuery);
            $checkStmt->bind_param("ss", $name, $email);

            // Iterate over the rows and check if any data already exists
            $exists = false;
            foreach ($objPHPExcel->getWorksheetIterator() as $worksheet) {
                foreach ($worksheet->getRowIterator() as $row) {
                    // Initialize variables
                    $name = '';
                    $email = '';

                    $cellIterator = $row->getCellIterator();
                    $cellIterator->setIterateOnlyExistingCells(false); // Loop through all cells, even if empty
                    $cellData = [];
                    foreach ($cellIterator as $cell) {
                        $cellData[] = $cell->getValue();
                    }

                    // Extracting data from cells
                    $name = isset($cellData[0]) ? $cellData[0] : '';
                    $email = isset($cellData[1]) ? $cellData[1] : '';

                    // Execute the existence check
                    $checkStmt->execute();
                    $checkStmt->bind_result($count);
                    $checkStmt->fetch();
                    if ($count > 0) {
                        $exists = true;
                        break 2; // Exit both foreach loops
                    }
                }
            }
            $checkStmt->close(); // Close statement

            // If any data already exists, show error and exit
            if ($exists) {
                echo "Error: Data already exists in the database. File could not be uploaded.";
            } else {
                // No data exists, proceed with inserting the file data into the database

                // Prepare and bind SQL statement for insertion
                $sql = "INSERT INTO user (name, email) VALUES (?, ?)";
                $stmt = $conn->prepare($sql);
                if (!$stmt) {
                    die("Error preparing statement: " . $conn->error);
                }
                $stmt->bind_param("ss", $name, $email);

                // Iterate over the rows and insert into database
                $successCount = 0;
                foreach ($objPHPExcel->getWorksheetIterator() as $worksheet) {
                    foreach ($worksheet->getRowIterator() as $row) {
                        // Initialize variables
                        $name = '';
                        $email = '';

                        $cellIterator = $row->getCellIterator();
                        $cellIterator->setIterateOnlyExistingCells(false); // Loop through all cells, even if empty
                        $cellData = [];
                        foreach ($cellIterator as $cell) {
                            $cellData[] = $cell->getValue();
                        }

                        // Extracting data from cells
                        $name = isset($cellData[0]) ? $cellData[0] : '';
                        $email = isset($cellData[1]) ? $cellData[1] : '';

                        // Execute statement
                        if ($stmt->execute()) {
                            $successCount++;
                        } else {
                            echo "Error: " . $sql . "<br>" . $conn->error;
                        }
                    }
                }
                $stmt->close(); // Close statement
                $conn->close(); // Close connection
                echo "Data imported successfully. $successCount new records added.";
            }
        } else {
            echo "Invalid file type. Please upload an Excel file.";
        }
    } else {
        echo "Error uploading file.";
    }
}
?>
